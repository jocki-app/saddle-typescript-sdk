# Selective, atomic CSDB merge

The JavaScript native and portable databases expose `db.merge(source, options)`.
Python exposes `db.merge(source, options)` with the same JSON configuration keys.
`source` may be a CSDB string, database, or document. `mergeDocuments` (JavaScript)
and `merge_documents` (Python) return a detached `{document, report}` result.
Neither input is mutated by these pure functions. Database methods apply the result
only after complete validation and honor the database's normal auto-save policy.
A failed merge changes neither the active document nor its persisted file.

```javascript
const report = destination.merge(source, {
  tables: [
    {
      source: "public.tasks",
      target: "public.tasks",
      columns: ["id", "title", "parent_id"],
      rows: { indices: [0, 1] },
    },
  ],
  include: ["data", "visibility", "comments", "foreign_keys"],
  conflicts: "update",
  metadata_conflicts: "source",
  missing_tables: "create",
  missing_columns: "add",
  missing_foreign_keys: "error",
});
```

```python
report = destination.merge(source, {
    "include": ["data", "visibility", "foreign_keys"],
    "conflicts": "update", "missing_tables": "create",
    "missing_columns": "add", "missing_foreign_keys": "error",
})
```

## Selection

Omit `tables` to select all source tables by qualified name. Each entry can be a
qualified name or `{source, target?, columns?, rows?}`. Duplicate sources or targets
are errors. An empty list selects nothing. Omitted `columns` selects all columns.
Row selectors intersect: zero-based `indices`, primary-key tuples `keys`, and a
structured CSDB expression `where`. Unknown columns, out-of-range row indices,
and keys with the wrong arity are errors. An empty selector list selects no rows.

`include` defaults to `["data"]`. Available parts: `data`, `columns`, `types`,
`comments`, `visibility`, `defaults`, `required`, `primary_key`, `unique`,
`foreign_keys`, `constraints`, `indexes`, `computed_fields`. `comments` refers to
structured `comments` mappings, including database and schema comments; it does
not transfer YAML `#` layout comments or machine indexes. Indexes are rebuilt for
the destination. Unknown parts and policy values are errors.

New tables necessarily receive selected column types, required fields, defaults,
primary and unique keys; presentation, foreign keys, constraints and indexes are
opt-in through `include`. Existing tables retain unselected definitions and data.
Adding a missing column fills existing rows with its source default or null.
Types are resolved in the source schema and copied inline into selected columns,
so remapping a table to another schema cannot silently reinterpret a local type.
`types` additionally copies named type declarations. Foreign-key targets are
remapped along with selected tables. Expressions referring to omitted columns
are rejected by ordinary schema validation rather than silently rewritten.

## Policies

| Option                 | Values                               | Default  |
| ---------------------- | ------------------------------------ | -------- |
| `conflicts`            | `error`, `skip`, `update`, `replace` | `error`  |
| `metadata_conflicts`   | `error`, `source`, `target`          | `target` |
| `missing_tables`       | `error`, `create`, `skip`            | `error`  |
| `missing_columns`      | `error`, `add`, `ignore`             | `error`  |
| `missing_foreign_keys` | `error`, `drop`, `null`              | `error`  |

Row conflicts match the destination primary key. `update` patches only selected
columns; `replace` resets unselected columns to destination defaults/null. Tables
without primary keys append rows; unique constraints still validate. Metadata
maps merge by key, named definitions by name, and key/required lists by value.
`target` retains conflicting definitions, `source` replaces them, `error` rejects.

Foreign-key `error` requires every selected result to be valid. `drop` explicitly
removes definitions with missing targets or unresolved values, reporting each
removal. `null` clears unresolved reference values but requires target definitions
to exist and affected columns to permit null. Other constraints always apply.
These policies never silently drop data rows. Defaults, enum/array codecs,
required values, uniqueness and foreign keys are validated for the complete
result, after all tables and rows have been assembled. This allows cycles and
self references without per-row commits. Primary-key matching uses one lookup
per destination table; data is serialized and indexes rebuilt once per merge.

The report contains `tables` entries with `source`, `target`, `inserted`, `updated`,
`skipped`, and final destination row ordinals in `rows`; `warnings` lists deliberate
skips or foreign-key changes. Row ordinals describe this result, not stable IDs.

## Opaque field visibility and reference labels

```yaml
visibility:
  id: hidden
  title: editable
  notes: any text understood by a consumer
foreign_keys:
  - name: parent
    columns: [parent_id]
    references:
      table: public.tasks
      columns: [id]
    label_field: title
```

Visibility maps existing columns to arbitrary strings. CSDB persists and returns
these strings without changing reads, writes, validation, or access control.
JavaScript `db.getVisibility("public.tasks", "title")` and
`db.table("public.tasks").getVisibility("title")` return the string or undefined;
Python uses `get_visibility` and returns None when absent. Omit the column to
return a detached mapping. Unknown tables/columns are errors. An absent mapping
normalizes to an empty mapping. No visibility vocabulary is reserved by CSDB.

`label_field` is an optional foreign-key property naming an existing column in
the referenced table. It need not be unique, required, or part of the target key.
It is presentation guidance only: key matching always uses `columns` and
`references.columns`. Self references use the same fully qualified table name.

## Positional row edits

Structured `update` commands also accept `row_indices`, a zero-based list of
row positions intersected with `where`. This permits editing exactly one row in
a table without a primary key, including duplicate rows. An out-of-range index
rejects the entire command. These are positions in the current document, not
stable identities: consumers must check their editing baseline before applying
an ordinal after concurrent changes. JavaScript and Python use the same plan
key, for example `{kind: "update", table: "public.rows", row_indices: [1],
set: {title: "Changed"}}` (a dictionary with quoted keys in Python).

`include` also accepts `formats`. Incoming nulls are preserved by default; `nulls: "defaults"` fills selected null values from the destination defaults, including native `now()`. See [Datetime formats and defaults](datetime.md).
