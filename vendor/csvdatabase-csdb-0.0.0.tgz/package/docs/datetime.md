# Datetime formats and `now()` defaults

`date` stores a calendar day. `timestamp` stores a date and time; `datetime` is an alias for `timestamp`. Date/time values can have a per-column text format in the table definition:

```yaml
schema: public
name: exercises
columns:
  name: text
  sets: integer
  reps: text
  date: datetime
required: [name, sets, reps]
defaults:
  date: now()
formats:
  date: "%d/%m/%Y %H:%M:%S%:z"
visibility:
  date: hidden
```

`formats` maps existing date/time columns to format strings. This controls their **CSV representation**, not a time zone conversion or a frontend visibility rule. It is optional; without it dates use `YYYY-MM-DD` and timestamps use ISO text. A reusable named date/time type may also declare `format`; a table's `formats` entry overrides that type's format. Formats on non-temporal columns, unknown columns, invalid directives, missing calendar parts, and invalid calendar dates fail validation, including when the table is empty.

Formats use a portable, locale-independent subset of strftime. Combine directives in any order with arbitrary literal separators; quote strings containing `%` in YAML.

| Directive | Meaning |
| --- | --- |
| `%Y` | Four-digit year, 0001–9999 |
| `%m`, `%d` | Two-digit month and day |
| `%H` | Two-digit hour, 00–23 |
| `%I`, `%p` | Two-digit hour, 01–12, and `AM`/`PM`; use together |
| `%M`, `%S` | Two-digit minute and second |
| `%f` | Six-digit fractional seconds |
| `%z` | Offset such as `-1000` (`Z` accepted on input) |
| `%:z` | Offset such as `-10:00` (`Z` accepted on input) |
| `%%` | Literal percent sign |

Each format requires exactly one `%Y`, `%m`, and `%d`. Directives cannot repeat. Date formats cannot include time or offset directives. Timestamp time components omitted by the format become zero on read; omitted fractional seconds and offsets are not retained. Choose a format containing the precision and offset you need. A format containing an offset directive requires a timestamp with an offset. Unsupported directives fail explicitly.

JavaScript SDK row values remain canonical ISO strings. Python row values remain native `date`/`datetime` objects. Supply canonical ISO strings or native Python values to insert/update. The SDK translates them to the configured CSV format, and translates the file back on read. Merely opening or serializing a file never evaluates a default.

## Current time

The exact string `now()` (case insensitive) is a built-in default for `date`, `timestamp`, and `datetime`. It is evaluated in UTC when an insert omits the column. All rows in one insert or merge use the same captured time. For `date`, it yields the UTC calendar day. For `text`, `now()` remains literal text. No general expression evaluation, JavaScript execution, Python execution or network access occurs. Other temporal default values must be valid typed literals.

Explicit null remains null. Parsing, saving, querying, updating another field, or synchronizing existing values does not refresh a timestamp. A new form can call `evaluateDefaults(table, now?)` in JavaScript or `evaluate_defaults(table, now=None)` in Python to initialize defaults without modifying the table. Those helpers resolve only defaults, not required values for unrelated columns.

## Reusable populated templates

A template can have blank nullable date cells and `defaults: {date: now()}`. Blanks remain null in the template itself. A merge can deliberately fill incoming nulls from destination defaults:

```js
destination.merge(template, { nulls: "defaults", missing_tables: "create" });
```

```python
destination.merge(template, {"nulls": "defaults", "missing_tables": "create"})
```

The default merge policy is `nulls: "preserve"`. `nulls: "defaults"` applies to selected incoming columns that are null and have a destination default; non-null source values and unrelated existing destination rows are preserved. Selected updates and replacements use the same rule. Defaults/format definitions are structural when creating a missing table or column; existing table definitions change only when selected by `include` and the metadata conflict policy. `include: ["formats"]` transfers a table's format map independently of its data. The whole merge remains atomic.
