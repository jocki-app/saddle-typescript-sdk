# CSDB TypeScript Library

> **Start here:** Project-wide information, planning, and community resources live in the [main CSDB repository](https://github.com/csvdatabase/csdb).

## Introduction

This repository contains the native TypeScript implementation of CSDB. It reads and writes `.csdb` files and supports fluent table queries and SQL.

The package name is `@csvdatabase/csdb`.

## Use

```bash
npm install @csvdatabase/csdb
```

```ts
import { openCSDB } from "@csvdatabase/csdb";

const db = await openCSDB("payroll.csdb");
const workers = db.table("public.workers").where("active", "=", true).all();
```

## Data constraints

SQL, fluent mutations, and structured plans enforce constraints in the shared executor: values are coerced first, then the resulting document is validated before indexes are rebuilt or autosave runs. Failed mutations restore rows and indexes. Primary/unique keys, required values, checks, and foreign keys are enforced; foreign-key targets must be primary or unique keys. Partial unique indexes apply only to matching rows, and unique expression indexes use the supported expression syntax. Expressions are parsed outside row loops and foreign-key target sets are reused within each validation pass.

Changes that would orphan referenced rows are rejected; cascade/set-null/set-default actions are not executed. See the [validation reference](https://docs.csvdatabase.net/reference/validation) for the pipeline and limits.

## Index placement and recovery

Configure indexes once per instance. Each type independently accepts `storage: "none" | "memory" | "file"`; all default to `none`.

```ts
const db = await openCSDB("payroll.csdb", {
  indexing: {
    sectionLocations: { storage: "memory" },
    rowLocations: { storage: "file" },
    keyLookups: { storage: "memory" },
    columnLookups: { storage: "file" },
  },
  autoSave: true,
  onIndexError: "reindex",       // default; alternatives: "halt", "scan"
  onMalformedFile: "halt",      // default; alternative: "keep-last-good"
});
try {
  const worker = db.table("public.workers").byPrimaryKey("w_001");
  console.log(db.indexStats); // file/memory accesses, rows read, table scans
} finally {
  db.close();
}
```

| Type | What it accelerates | Requires |
| --- | --- | --- |
| `sectionLocations` | Schema/data byte-range lookup | Nothing |
| `rowLocations` | Individual record reads, including `first()`/`limit()` without sorting | Section locations |
| `keyLookups` | Primary/unique key lookup and referenced-key joins | Row locations |
| `columnLookups` | Declared column indexes and foreign-key source lookups | Row locations |

Dependencies must be explicitly enabled; they may use different storage backends. Invalid combinations fail before any file repair. File indexes require a path. Memory indexes remain in memory; file indexes use fixed-width records read from the file. No-index file-backed instances scan CSV as needed without retaining all parsed rows. `parseCSDB(text)` necessarily retains its source text in memory.

SELECT, fluent lookups, equality joins, UPDATE and DELETE consult applicable indexes. Unsupported predicates fall back to scanning with the same expression semantics. Full composite equality is supported. Single-column ranges scan index entries and fetch matching rows; they are not logarithmic range seeks. Partial/expression unique constraints remain enforced, but partial/expression query acceleration is not part of these four types.

All byte references store lengths: ordered section sizes and CSV header/record lengths. Reads and writes sum these at call time; batches accumulate lengths once. Growing one row changes its length entry and containing section descriptor, leaving subsequent length entries unchanged. Key and column lookups reference row ordinals. A late-row read must sum preceding lengths.

When any index is stored in the file, its last section is exactly 1,024 bytes, including `--- footer\n`. It stores the byte length of the directory immediately above it: `directoryStart = fileSize - 1024 - directoryLength`. That directory contains section sizes and checksums and locates the individual indexes by summation. No stored location is absolute or cumulative.

Open performs full integrity validation and constructs/verifies the requested indexes. Writes use the active indexes, temporarily materialize and validate the complete document, then update the affected record lengths, lookups, section descriptors and footer. Untouched human/index sections and memory entries are reused. Updating an unindexed column preserves key/column indexes; changing an indexed value updates every affected lookup. Insert/delete can renumber the affected table's rows. Saving a prepared generation does not rebuild its indexes. This implementation still rewrites the file on save; it does not provide WAL or concurrent transaction isolation.

Missing, corrupt, or stale requested file indexes are rebuilt by default; enabling file storage can therefore rewrite derived sections on open. `halt` rejects an index error or an external generation change. `scan` uses valid source data without acceleration until the next rebuild. Generation checks use file identity, size, modification time and change time. Full verification on open also checks derived bytes against a rebuilt representation, so corrupted lengths or incomplete entries cannot be trusted merely because their checksum was recomputed.

Malformed source records are never skipped or overwritten. `keep-last-good` retains a validated source snapshot, serves it read-only if a later reread is malformed, and blocks mutations/saves until the source is valid again. It cannot rescue an initially malformed file. External changes while local mutations are unsaved raise `CSDB_CONFLICT`.

Without autosave, pending changes in a file-backed instance use a private temporary snapshot; `saveSync()` persists them, and `close()` removes temporary files (discarding unsaved changes). Returned rows and `db.document` are detached snapshots: use mutation APIs to update the database. `resetIndexStats()` resets access counters.

Compatibility: human CSDB v2 data remains supported. New derived sections use `index_format: 3`. Format 2 and legacy machine sections are rebuilt by default when file indexing is requested (`halt` rejects them; `scan` ignores them); `machine_indexing` no longer chooses instance placement. `serializeDocument()` emits human data; `db.toString()` includes this instance's enabled file indexes. The legacy `machineIndexes: "omit"` option is retained for exporting human data, and cannot remove indexes required when saving the instance's own source.

## Development

The library requires Node.js 20.12 or newer. Install dependencies and run the checks:

```bash
npm ci
npm run check
```

See the [release process](RELEASING.md) and [security policy](SECURITY.md) for maintainer procedures.

## Schemas, enums and arrays

Format version 2 requires every table to belong to an explicitly declared schema. All SQL, fluent, foreign-key and JSON table references use `schema.table`. Table definitions use separate `schema` and local `name` fields. An existing database may already declare `public`; no schema is created implicitly. Version 1 and old section headers are rejected.

```sql
CREATE SCHEMA work;
CREATE TYPE work.priority AS ENUM ('low', 'normal', 'high');
CREATE TABLE work.tasks (id integer PRIMARY KEY, priority work.priority, priorities work.priority[]);
INSERT INTO work.tasks (id, priority, priorities) VALUES (1, 'high', ARRAY['low', 'high']);
SELECT priority FROM work.tasks;
```

```ts
db.createSchema("work");
db.createType("work.priority", { type: "enum", options: ["low", "normal", "high"] });
db.createTable({ schema: "work", name: "tasks", columns: {
  id: "integer",
  priority: "priority",
  priorities: { type: "priority", inputMode: "array" }
} });
db.table("work.tasks").insert({ id: 1, priority: "high", priorities: ["low", "high"] });
// Remove dependents before their type or schema:
db.dropTable("work.tasks");
db.dropType("work.priority");
db.dropSchema("work");
```

```py
db.create_schema("work")
db.create_type("work.priority", {"type": "enum", "options": ["low", "normal", "high"]})
db.create_table({"schema": "work", "name": "tasks", "columns": {
    "id": "integer", "priority": "priority", "priorities": {"type": "priority", "inputMode": "array"},
}})
db.table("work.tasks").insert({"id": 1, "priority": "high", "priorities": ["low", "high"]})
db.drop_table("work.tasks")
db.drop_type("work.priority")
db.drop_schema("work")
```

The SQL, TypeScript and Python blocks show alternative ways to perform the same operations. Remote TypeScript SDK methods have the same names and return promises; `await` each DDL or write. A reusable type can be used on multiple fields and tables in its owning schema. Cross-schema references, unknown types/columns, invalid enum choices, invalid array elements and invalid defaults are errors. Dropping a referenced type or nonempty schema also fails. Failed writes and DDL preserve the previous database.

`type: enum` requires string `options`. Other types may optionally define typed `options`, such as integer `[1, 2, 3]`. `inputMode: enum` accepts one scalar; `inputMode: array` accepts an ordered list of the underlying type. Native `{ type: "array", items: "priority" }` and `priority[]` are equivalent list declarations. Arrays support `minItems`, `maxItems`, `uniqueItems`, null elements and nested element types. A null field, `[]` and `[null]` are distinct. Arrays are stored as JSON text within a CSV cell; bigint and exact decimal elements use strings for precision.

The corresponding file uses `--- schema:work`, `--- table:work:tasks`, then `--- data:tasks`. The short data section is attached to the immediately preceding table definition.

## Browser and embedded command API

Import `@csvdatabase/csdb/portable` for a browser, mobile WebView or host-managed file draft. This entry point has no Node, filesystem or Buffer dependency. It shares the native entry point's parser, codecs, validation, SQL parser and executor, while operating on in-memory rows. The host owns durable persistence; serialize and save only after commands succeed. File-backed index configuration belongs to the native entry point.

```ts
import { CSDBDatabase } from "@csvdatabase/csdb/portable";
const db = CSDBDatabase.create("tasks");
db.createSchema("public");
db.createTable({ schema: "public", name: "tasks", columns: { id: "text" }, required: ["id"], primary_key: { columns: ["id"] } });
db.table("public.tasks").insert({ id: "a" });
const table = db.document.tables.get("public.tasks")!;
db.alterTable({ ...table.schema, columns: { id: "text", scores: { type: "integer", inputMode: "array", options: [1, 2, 3] } }, defaults: { scores: [1] } });
const text = db.toString();
```

`alterTable(definition)` changes the actual table definition in both entry points. It adds/removes/reorders columns, updates types, choices, required fields, defaults and comments, and converts or backfills existing rows. Schema and local table name must still identify an existing table. Dropped values are removed. Invalid values or dependent keys/constraints reject the entire change and preserve the previous database. Use `{ kind: "alter-table", schema: definition }` with `execute` for the equivalent structured command. There is no dedicated SQL ALTER TABLE syntax or column-rename operation yet.

The portable `batch(plans)` method applies all supplied commands atomically. A failed command publishes none of the changes. The `document` getter and command results are detached snapshots; modify data through commands. `CSDBDatabase.create(metadata)` also accepts a version 2 metadata object and retains application metadata while constructing schema/table order through commands. `parseCsv`, `stringifyCsv`, `resolveType`, `columnType`, `encodeValue` and `decodeCell` are exported for host-managed interchange and cell projections. JSON strings are native string values, as in Python; pass an object/list when storing JSON objects/arrays.

## Forms and selective merges

Table schemas support opaque per-column `visibility` text and foreign-key `label_field` display hints. Both are validated and round-trip through the SDK. Use `getVisibility` (`get_visibility` in Python) to read visibility. The database `merge` API imports selected tables, rows, columns and definitions atomically with explicit conflict policies. See [the merge and form metadata API](docs/merge.md).

See [Datetime formats and now() defaults](docs/datetime.md) for temporal formats, UTC defaults, and reusable populated templates.
